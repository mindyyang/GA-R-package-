# GA
An R package to implement a genetic algorithm for variable selection in regression problems

## Installation

Install directly from github. 

```
install_github('RPackageGroupProject/GA')
```

or clone repo and install. 

```
install('GA')
```

## Examples

see ?select
